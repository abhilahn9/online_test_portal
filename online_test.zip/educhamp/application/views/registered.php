<!DOCTYPE html>
<html>
	<head>
		<title>Registered</title>
		<link rel="stylesheet" href="https://cdn.rawgit.com/Chalarangelo/mini.css/v3.0.1/dist/mini-default.min.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<style>
			body {
				text-align: center;
				margin-top: 10%;
			}
		</style>
	</head>
	<body>
		Account created. You can <a class="button" href="<?php echo base_url();?>index.php/login">login</a> now.
	</body>
</html>